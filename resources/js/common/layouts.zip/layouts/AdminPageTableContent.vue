<template>
    <div class="dashboard-page-content-container">
        <slot></slot>
    </div>
</template>

<script>
import { defineComponent } from "vue";

export default defineComponent({
    setup() {
        return {};
    },
});
</script>
